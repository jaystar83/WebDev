export class Todo {
    id: string;
    title: string;
    done: boolean;
}
