# PWA Praxisbuch Demo-Server

[![NPM Version](https://img.shields.io/npm/v/pwapraxis-server.svg)](https://www.npmjs.com/package/pwapraxis-server)
[![Package License](https://img.shields.io/npm/l/pwapraxis-server.svg)](https://www.npmjs.com/package/pwapraxis-server)
[![Travis CI](https://travis-ci.org/pwapraxis/server.svg?branch=master)](https://greenkeeper.io/)
[![Greenkeeper badge](https://badges.greenkeeper.io/pwapraxis/server.svg)](https://greenkeeper.io/)

## Usage
On your command line, run:
```
$ pwapraxis-server
```
