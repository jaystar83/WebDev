import { ChangeDetectionStrategy, Component } from '@angular/core';

@Component({
  selector: 'app-help',
  templateUrl: './help.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class HelpComponent {
}
