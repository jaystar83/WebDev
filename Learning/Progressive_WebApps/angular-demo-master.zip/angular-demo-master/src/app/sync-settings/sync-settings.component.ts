import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sync-settings',
  templateUrl: './sync-settings.component.html',
  styleUrls: ['./sync-settings.component.css']
})
export class SyncSettingsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
