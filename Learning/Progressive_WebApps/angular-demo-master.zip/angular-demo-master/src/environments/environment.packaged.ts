export const environment = {
  production: false,
  baseUrl: 'https://pwapraxisapi.azurewebsites.net/',
  useHashBasedRouting: true,
  pushPublicKey: 'BMoIsjqNzO7lCOX-GCeWyRn3nEO6SrmbmLK9v3-XAU7EXL0BmMeP7P9rCZ9cMOA0rmVeZPgx5KK1J-HCw797_Fg'
};
